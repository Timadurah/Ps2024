CREATE TABLE MyGuests (
    id int NOT NULL AUTO_INCREMENT,
    firstname varchar(255) NOT NULL,
    lastname varchar(255),
    email varchar(255),
    phone varchar(255),
    passwd varchar(255),
    PRIMARY KEY (id)
);

CREATE TABLE AvailableInvestment (
    id int NOT NULL AUTO_INCREMENT,
    label varchar(255) NOT NULL,
    banner varchar(255),
    countdown varchar(255),
    description varchar(255),
    companyName varchar(255),
    companyLogo varchar(255),
    currentBid varchar(255),
    incomePercentage varchar(255),
    PRIMARY KEY (id)
);

CREATE TABLE Balance (
    user_id varchar(255),
    balance varchar(255)
);