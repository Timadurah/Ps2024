<?php
session_start();

$servername = "localhost";
$username = "root";
$serverKey = "";
$dbname = "Mr.404";
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $serverKey);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $stmt = $conn->prepare("SELECT * FROM MyGuests WHERE id='".$_SESSION['KoKOMelon']."'");
    $stmt->execute();
    foreach ($stmt as $key) {
      $email = $key['email'];
    }




// Pay with Transfer (PwT) is a feature that allow merchants or businesses create temporary bank accounts that customers can use to pay for goods or services. The account number is generated and tied to the current customer’s transaction. The account number becomes invalid after the customer’s transaction or when it exceeds it’s expiry time.

// Create a PwT charge
// At the point of payment, you initiate a request to the Create ChargeAPI endpoint, passing the email, amount and bank_transfer object. The bank_transfer object takes the account_expires_at which is used to set the expiry of an account number for a transaction:



  $curl = curl_init();
  @$amount_fund_account = $_POST['FundAmount'];
  @$user_email_account = $_POST['email'];

  curl_setopt_array($curl, array(
    CURLOPT_URL => "https://api.paystack.co/charge",
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => "",
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => "POST",
    CURLOPT_POSTFIELDS => [
      "email" => $user_email_account, 
      "amount" => $amount_fund_account,
      "bank_transfer" => [
        "account_expires_at" => "null"
      ]
    ],
    CURLOPT_HTTPHEADER => array(
      "Authorization: Bearer SECRET_KEY",
      "Cache-Control: no-cache"
    ),
  ));

  $response = curl_exec($curl);
  $err = curl_error($curl);

  curl_close($curl);

  if ($err) {
    echo "cURL Error #:" . $err;
  } else {
    echo $response;

    if ($response['status'] == 'success') {
       // get legabalance den add up to update
    $ch__legb = $conn->prepare("SELECT * FROM legalbalance WHERE user_id='".$_SESSION['KoKOMelon']."'");
                                                         $ch__legb->execute(); 
                                                         foreach ($ch__legb as $baly) {
                                                            $balancebook = $baly['balance'];
                                                         }
    $bn = $amount_fund_account + $balancebook;
    $legalBalance = $conn->prepare("UPDATE legalbalance SET balance=".$bn." WHERE user_id=".$_SESSION['KoKOMelon']."");
    // commit the transaction
    $legalBalance->execute();
        header("Location: ./");


    }
  }
?>
