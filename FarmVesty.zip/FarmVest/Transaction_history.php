
<?php
session_start();
if (empty($_SESSION['KoKOMelon'])) {
    header("Location: ./sign.php");
}
else {
require './materia.php';
require './h2.php';

$servername = "localhost";
$username = "root";
$serverKey = "";
$dbname = "Mr.404";
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $serverKey);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $stmt = $conn->prepare("SELECT * FROM MyGuests WHERE id='".$_SESSION['KoKOMelon']."'");
    $stmt->execute();
    foreach ($stmt as $key) {
      $firstname = $key['firstname'];
      $lastname = $key['lastname'];
      $email = $key['email'];
      $phone = $key['phone'];
      $profile = $key['profile'];
      $date = $key['date'];
    }
?>
<br>
<br>
<br>
<br>
      <div class="page-title-overlap bg-accent pt-4">
        <div class="container d-flex flex-wrap flex-sm-nowrap justify-content-center justify-content-sm-between align-items-center mb-2 pt-2">
          <div class="d-flex align-items-center">
            <div class="img-thumbnail rounded-circle position-relative flex-shrink-0" style="width: 6.375rem;"><img class="rounded-circle" src="./files/<?=$profile;?>" alt="@foxnet_creator"></div>
            <div class="ps-3">
              <h3 class="h5 mb-2 text-light">@<?=$firstname;?></h3><span class="d-block text-light fs-sm opacity-60">Joined <?=$date;?></span>
            </div>
          </div>
       
        </div>
      </div>
      <div class="container mb-5 pb-3">
        <div class="bg-light shadow-lg rounded-3 overflow-hidden">
          <div class="row">
            <!-- Sidebar-->
           <?php require './aside.php'; ?>
            <!-- Content-->
            <section class="col-lg-9 pt-lg-4 pb-4 mb-3">
              <div class="pt-2 px-4 ps-lg-0 pe-xl-5">
                <h1 class="h3 mb-4 pt-2 text-center text-sm-start">Transactions </h1>
                     <!--  -->
                            


<div class="table-responsive fs-md mb-4">
              <table class="table table-hover mb-0">
                <thead>
                  <tr>
                    <th>Payment ID#</th>
                    <th>Date</th>
                    <th>Status</th>
                    <th>Total</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td class="py-3"><a class="nav-link-style fw-medium fs-sm" href="#order-details" data-bs-toggle="modal">34VB5540K83</a></td>
                    <td class="py-3">May 21, 2019</td>
                    <td class="py-3"><span class="badge bg-info m-0">In Progress</span></td>
                    <td class="py-3">$358.75</td>
                  </tr>
                  <tr>
                    <td class="py-3"><a class="nav-link-style fw-medium fs-sm" href="#order-details" data-bs-toggle="modal">78A643CD409</a></td>
                    <td class="py-3">December 09, 2018</td>
                    <td class="py-3"><span class="badge bg-danger m-0">Canceled</span></td>
                    <td class="py-3"><span>$760.50</span></td>
                  </tr>
                  <tr>
                    <td class="py-3"><a class="nav-link-style fw-medium fs-sm" href="#order-details" data-bs-toggle="modal">112P45A90V2</a></td>
                    <td class="py-3">October 15, 2018</td>
                    <td class="py-3"><span class="badge bg-warning m-0">Delayed</span></td>
                    <td class="py-3">$1,264.00</td>
                  </tr>
                  <tr>
                    <td class="py-3"><a class="nav-link-style fw-medium fs-sm" href="#order-details" data-bs-toggle="modal">28BA67U0981</a></td>
                    <td class="py-3">July 19, 2018</td>
                    <td class="py-3"><span class="badge bg-success m-0">Delivered</span></td>
                    <td class="py-3">$198.35</td>
                  </tr>
                  <tr>
                    <td class="py-3"><a class="nav-link-style fw-medium fs-sm" href="#order-details" data-bs-toggle="modal">502TR872W2</a></td>
                    <td class="py-3">April 04, 2018</td>
                    <td class="py-3"><span class="badge bg-success m-0">Delivered</span></td>
                    <td class="py-3">$2,133.90</td>
                  </tr>
                  <tr>
                    <td class="py-3"><a class="nav-link-style fw-medium fs-sm" href="#order-details" data-bs-toggle="modal">47H76G09F33</a></td>
                    <td class="py-3">March 30, 2018</td>
                    <td class="py-3"><span class="badge bg-success m-0">Delivered</span></td>
                    <td class="py-3">$86.40</td>
                  </tr>
                </tbody>
              </table>
            </div>


                     <!--  -->
              </div>
            </section>
          </div>
        </div>
      </div>
    </main><?php

require './footer.php';
}
?>
