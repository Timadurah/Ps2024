<?php
session_start();
require './materia.php';
require './header.php';

    ?>
<br>
<br>

<div class="container py-4 py-lg-5 my-4">
        <div class="row justify-content-center align-items-center">
          <div class="col-md-6">
            <div class="card border-0 shadow">
              <div class="card-body">
                <h2 class="h4 mb-1">Verification Code [Otp]</h2>
                <div class="py-3">
                  <h3 class="d-inline-block align-middle fs-base fw-medium mb-2 me-2">Enter Verification code send to your email. <small style="color: pink;">Note:you may need to check your spam box</small></h3>
                </div>
                <form class="needs-validation"  action="./forget_password.php" method="post">
                    <div class="text-danger"> <?php echo @$_SESSION['otp__response']." *"; ?> </div>
                    <div class="input-group mb-3"><i class="ci-locked position-absolute top-50 translate-middle-y text-muted fs-base ms-3"></i>
                    <input required class="form-control rounded-start" type="password" name="Verification" placeholder="Verification_code" required>
                  </div><div class="input-group mb-3"><i class="ci-locked position-absolute top-50 translate-middle-y text-muted fs-base ms-3"></i>
                    <input required class="form-control rounded-start" type="password" name="new_password" placeholder="New Password" required>
                  </div>
                  <div class="text-center pt-4 ">
                    <button class="btn btn-primary" type="submit"> Verify </button>
                  </div>
                </form>
              </div>
            </div>
          </div>         
          </div>
      </div>
<br>
<br>
<br>
<br>
<br>
<br>




<?php

require 'footer.php';

?>



