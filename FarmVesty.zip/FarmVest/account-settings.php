
<?php
session_start();
if (empty($_SESSION['KoKOMelon'])) {
    header("Location: ./sign.php");
}
else {
require './materia.php';
require './h2.php';

$servername = "localhost";
$username = "root";
$serverKey = "";
$dbname = "Mr.404";
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $serverKey);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $stmt = $conn->prepare("SELECT * FROM MyGuests WHERE id='".$_SESSION['KoKOMelon']."'");
    $stmt->execute();
    foreach ($stmt as $key) {
      $firstname = $key['firstname'];
      $lastname = $key['lastname'];
      $email = $key['email'];
      $phone = $key['phone'];
      $profile = $key['profile'];
      $date = $key['date'];
    }


// balance
     $baly = $conn->prepare("SELECT * FROM legalbalance WHERE user_id='".$_SESSION['KoKOMelon']."'");
    $baly->execute();
    foreach ($baly as $keyi) {
      $balancey = $keyi['balance'];
    }


    // bonus
     
    $ch__ = $conn->prepare("SELECT * FROM bonus WHERE referal='".$email."'");
    $ch__->execute();
    $ch_Count = $ch__->rowCount(); 
    $bonus =  $ch_Count * 1500;   
  
$erry = $conn->prepare("SELECT * FROM invest WHERE investor_id='".$_SESSION['KoKOMelon']."'");
$erry->execute();
$counter = $erry->rowCount();
$tota = 0;
foreach ($erry as $ke) {
  $tota += $ke;
}
 $welcomeb = $conn->prepare("SELECT * FROM WelcomeBonus WHERE user_id='".$_SESSION['KoKOMelon']."'");
    $welcomeb->execute();
    foreach ($welcomeb as $welcomebkey) {
      $Welcomebonus = $welcomebkey['balance'];
    }
?>
<br>
<br>
<br>
<br>
      <div class="page-title-overlap bg-accent pt-4">
        <div class="container d-flex flex-wrap flex-sm-nowrap justify-content-center justify-content-sm-between align-items-center mb-2 pt-2">
          <div class="d-flex align-items-center">
            <div class="img-thumbnail rounded-circle position-relative flex-shrink-0" style="width: 6.375rem;"><img class="rounded-circle" src="./files/<?=$profile;?>" alt="@foxnet_creator"></div>
            <div class="ps-3">
              <h3 class="h5 mb-2 text-light">@<?=$firstname;?></h3><span class="d-block text-light fs-sm opacity-60">Joined <?=$date;?></span>
            </div>
          </div>
       
        </div>
      </div>
      <div class="container mb-5 pb-3">
        <div class="bg-light shadow-lg rounded-3 overflow-hidden">
          <div class="row">
            <!-- Sidebar-->
           <?php require './aside.php'; ?>
            <!-- Content-->
            <section class="col-lg-9 pt-lg-4 pb-4 mb-3">
              <div class="pt-2 px-4 ps-lg-0 pe-xl-5">


                <!--  -->
                <div class="container pb-5 mb-sm-4">
        <div class="pt-5">
          <div class="card py-3 mt-sm-3">
            <div class="card-body text-left">
              <h2 class="h4 pb-3">Welcome <?=$firstname;?> <?=$lastname;?></h2>
              <p class="fs-sm mb-2">Phone Number <span class='fw-medium'>: </span><span class='fw-medium' style='color:lightblue; font-weight:bolder;'> <?=$phone;?> </span></p>
              <p class="fs-sm mb-2">Mail Address <span class='fw-medium'>: </span><span class='fw-medium' style='color:lightblue; font-weight:bolder;'> <?=$email;?> .</span></p>
              <p class="fs-sm mb-2">Total Affliate <span class='fw-medium'>: </span><span class='fw-medium' style='color:lightblue; font-weight:bolder;'> <?=$ch_Count;?>.</span></p>
              <p class="fs-sm mb-2">Welcome Bonus <span class='fw-medium'>: </span>  <?php  
                      if (@$Welcomebonus < 1) {
                        echo "<span class='fw-medium' style='color:pink; font-weight:bolder;'>You have 0Ng welcome bonus.</span>";
                      }
                      else{
                        echo "<span class='fw-medium' style='color:lightblue;'>You have ".$Welcomebonus."Ng welcome bonus.</span>";
                      }

                      ?>
.</p>

              <p class="fs-sm mb-2">Total investment <span class='fw-medium'>: </span><span class='fw-medium' style='color:lightblue; font-weight:bolder;'> <?=$counter;?>.</span></p>
             
              <p class="fs-sm mb-2">Withdrawed Amount <span class='fw-medium'>: </span><span class='fw-medium' style='color:lightblue; font-weight:bolder;'> <?=@$balancey;?> NG.</span></p>
              

              <div class="d-flex align-items-center justify-content-between">
                 <a class="d-flex align-items-center justify-content-center m-auto my-4 btn btn-outline-primary fw-bolder col-lg-5" style="font-family: monospace; ">WithdrawAble Amount <?=@$balancey;?>NG</a>

                            <a class=" col-lg-5 d-flex text-info align-items-center justify-content-center m-auto my-4 btn btn-secondary" href="./my_withdraw.php"> Make a withdraw</a>    </div>  
                          
                          </div>
          </div>
        </div>
      </div>
              <!--  -->
              </div>
            </section>
          </div>
        </div>
      </div>
    </main><?php
require './footer.php';
}
?>
