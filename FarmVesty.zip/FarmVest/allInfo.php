<?php
$servername = "localhost";
$username = "root";
$serverKey = "";
$dbname = "mr.404";
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $serverKey);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);


    // investments
    
  $investment__ = $conn->prepare("SELECT * FROM availableinvestment");
  $investment__->execute();
  $investment_counter = $investment__->rowCount();

//   user count
$User__ = $conn->prepare("SELECT * FROM myguests");
$User__->execute();
$user_counter = $User__->rowCount();

// refered user
$refered = $conn->prepare("SELECT * FROM bonus");
$refered->execute();
$refered_counter = $refered->rowCount();

// direct registered
$Direct_reg_counter = $user_counter - $refered_counter;

// Total bonus user earned
$Bonus_earned = $refered_counter * intval($uses['bonus']);







?>