 <aside class="col-lg-3 pe-xl-5">
              <!-- Account menu toggler (hidden on screens larger 992px)-->
              <div class="d-block d-lg-none p-4"><a class="btn btn-outline-accent d-block" href="#account-menu" data-bs-toggle="collapse"><i class="ci-menu me-2"></i>Account menu</a></div>
              <!-- Actual menu-->
              <div class="h-100 border-end mb-2">
                <div class="d-lg-block collapse" id="account-menu">
                  <ul class="list-unstyled mb-0">
                    <li class="border-bottom mb-0"><a class="nav-link-style d-flex align-items-center px-4 py-3" href="./account-settings.php"><i class="ci-settings opacity-60 me-2"></i>Profile Settings</a></li>  
                    <li class="border-bottom mb-0"><a class="nav-link-style d-flex align-items-center px-4 py-3" href="my_invest.php"><i class="ci-view-list opacity-60 me-2"></i>My Invests</a></li>

                    <li class="border-bottom mb-0"><a class="nav-link-style d-flex align-items-center px-4 py-3" href="./deposit.php"><i class="ci-add-circle opacity-60 me-2"></i>Deposit</a></li>

                    <li class="border-bottom mb-0"><a class="nav-link-style d-flex align-items-center px-4 py-3" href="./my_withdraw.php"><i class="ci-currency-exchange opacity-60 me-2"></i>Withdraw</a></li>
                    <li class="border-bottom mb-0"><a class="nav-link-style d-flex align-items-center px-4 py-3" href="./bonus.php"><i class="ci-smile opacity-60 me-2"></i>Bonus</a></li>

                    <li class="border-bottom mb-0"><a class="nav-link-style d-flex align-items-center px-4 py-3" href="./Transaction_history.php"><i class="ci-book opacity-60 me-2"></i>Transaction history</a></li><li class="mb-0"><a class="nav-link-style d-flex align-items-center px-4 py-3" href="./logout.php"><i class="ci-sign-out opacity-60 me-2"></i>Sign out</a></li>
                  </ul>
                </div>
              </div>
            </aside>