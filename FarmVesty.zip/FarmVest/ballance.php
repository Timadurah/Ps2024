<?php
$servername = "localhost";
$username = "username";
$serverKey = "password";
$dbname = "mr.404";
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $serverKey);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $stmt = $conn->prepare("SELECT * FROM wallet WHERE id='".$_SESSION['KoKOMelon']."'");
    $stmt->execute();
          foreach ($stmt as $key) {
                     $balance = $key['amount'];    
}
   
$conn = null;

?>