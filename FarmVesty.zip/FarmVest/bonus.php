
<?php
session_start();
if (empty($_SESSION['KoKOMelon'])) {
    header("Location: ./sign.php");
}
else {
require './materia.php';
require './h2.php';

$servername = "localhost";
$username = "root";
$serverKey = "";
$dbname = "Mr.404";
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $serverKey);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $stmt = $conn->prepare("SELECT * FROM MyGuests WHERE id='".$_SESSION['KoKOMelon']."'");
    $stmt->execute();
    foreach ($stmt as $key) {
      $firstname = $key['firstname'];
      $lastname = $key['lastname'];
      $email = $key['email'];
      $phone = $key['phone'];
      $profile = $key['profile'];
      $date = $key['date'];
    }
    $welcomeb = $conn->prepare("SELECT * FROM WelcomeBonus WHERE user_id='".$_SESSION['KoKOMelon']."'");
    $welcomeb->execute();
    foreach ($welcomeb as $welcomebkey) {
      $Welcomebonus = $welcomebkey['balance'];
    }
?>
<br>
<br>
<br>
<br>
      <div class="page-title-overlap bg-accent pt-4">
        <div class="container d-flex flex-wrap flex-sm-nowrap justify-content-center justify-content-sm-between align-items-center mb-2 pt-2">
          <div class="d-flex align-items-center">
            <div class="img-thumbnail rounded-circle position-relative flex-shrink-0" style="width: 6.375rem;"><img class="rounded-circle" src="./files/<?=$profile;?>" alt="@foxnet_creator"></div>
            <div class="ps-3">
              <h3 class="h5 mb-2 text-light">@<?=$firstname;?></h3><span class="d-block text-light fs-sm opacity-60">Joined <?=$date;?></span>
            </div>
          </div>
       
        </div>
      </div>
      <div class="container mb-5 pb-3">
        <div class="bg-light shadow-lg rounded-3 overflow-hidden">
          <div class="row">
            <!-- Sidebar-->
           <?php require './aside.php'; ?>
            <!-- Content-->
            <section class="col-lg-9 pt-lg-4 pb-4 mb-3">
              <div class="pt-2 px-4 ps-lg-0 pe-xl-5">


              <div class="d-flex  w-100 flex-column">
            <div class="img-thumbnail rounded-circle position-relative flex-shrink-0" style="width: 6.375rem;"><img class="rounded-circle" src="./files/<?=$profile;?>" alt="@foxnet_creator"></div>
            <div class="ps-3">
              <h3 class="h5 mb-2 text-muted m-3"><?=$firstname;?></h3></span></h3>
              <small class="h7 mb-2 text-muted m-3 border-bottom"> This is your Referal Link  <span style="margin-left: 10px; color: lightgreen;"> <?=$_SERVER['HTTP_HOST']?>/sign.php?ref=<?=$email;?></span></small>
            </div>
          </div>
       
          <br>
                <i><h1 class="h3 mb-4 pt-2 text-center text-sm-start">Welcome Bonus.</h1></i>
                     <!--  -->
                     <div class="table-responsive fs-md mb-4 px-3 text-muted" style="border-left: 5px solid gray; border-radius: 20px; font-family: monospace;">
                      <?php  
                      if (@$Welcomebonus < 1) {
                        echo "<span style='color:pink; font-weight:bolder;'>You have 0Ng welcome bonus.</span>";
                      }
                      else{
                        echo "<span style='color:#6610f2;'>You have been credited with ".$Welcomebonus."Ng welcome bonus.</span>";
                      }

                      ?>

</div>
                    <br>
                <i><h1 class="h3 mb-4 pt-2 text-center text-sm-start">referals stat.</h1></i>
                     <!--  -->
                            


<div class="table-responsive fs-md mb-4">
              <table class="table table-hover mb-0">
                <thead>
                  <tr>
                    <th>Referal ID #</th>
                    <th>Date</th>
                    <th>Status</th>
                    <th>Earn</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  
    $ch__ = $conn->prepare("SELECT * FROM bonus WHERE referal='".$email."'");
    $ch__->execute();
    $ch_Count = $ch__->rowCount(); 
    $bonus =  $ch_Count * 1500;   
    if ($ch_Count < 1) {
      echo "No referal History found, Share your referal link to make 1500 NG per registration.";
    }
    else {
      
  
    foreach ($ch__ as $bonuses) {
      # code...
 


                  ?>
                  <tr>
                    <td class="py-3"><a class="nav-link-style fw-medium fs-sm" href="#order-details" data-bs-toggle="modal"><?=$bonuses['refer']?></a></td>
                    <td class="py-3"><?=$bonuses['date'];?></td>
                    <td class="py-3"><span class="badge bg-info m-0">Registered</span></td>
                    <td class="py-3">1500 NG</td>
                  </tr>

                  <?php
}}
                  ?>
                  <!-- total -->
                   <tr style="border-bottom: 0px solid transparent !important;">
                    <td class="py-3"></td>
                    <td class="py-3"></td>
                    <td class="py-3">Total Referal Earned</td>
                    <td class="py-3"><?=@$bonus?> NG</td>
                  </tr>
                   <!-- general total -->
                   <tr style="border-bottom: 0px solid transparent !important;">
                    <td class="py-3"></td>
                    <td class="py-3"></td>
                    <td class="py-3">Total Earned</td>
                    <td class="py-3"><?=@$bonus + @$Welcomebonus?> NG</td>
                  </tr>
                 
                </tbody>
              </table>

            
            </div>


                     <!--  -->
              </div>
            </section>
          </div>
        </div>
      </div>
    </main><?php

require './footer.php';
}
?>
