
<?php
session_start();
if ($_SESSION['pussy'] !== 'ps2024') {
  header("location: ./smile.php");
}
else{
  require './materia.php';
  require './h2.php';
  
  ?>
  <br>
  <br>
  <br>
  <br>
        
        <div class="container mb-5 pb-3">
          <div class="bg-light shadow-lg rounded-3 overflow-hidden">
            <div class="row">
              <!-- Sidebar-->
             <?php require './asideTopussy.php'; ?>
             <section class="col-lg-8 pt-lg-4 pb-4 mb-3">
              <div class="pt-2 px-4 ps-lg-0 pe-xl-5">
              <form action="./upload.php" method="post" enctype="multipart/form-data"> 

                <!-- Title-->
                <div class="d-sm-flex flex-wrap justify-content-between align-items-center pb-2">
                  <h2 class="h3 py-2 me-2 text-center text-sm-start">Add New Product</h2>
                  <div class="py-2">
                    <select class="form-select me-2" id="unp-category" name="tier"> 
                      <option>Select Tier</option>
                      <option value="1" name="tier">Tier 1</option>
                      <option value="2" name="tier">Tier 2</option>
                      <option value="3" name="tier">Tier 3</option>
                      <option value="4" name="tier">Tier 4</option>
                      <option value="5" name="tier">Tier 5</option>
                      <option value="6" name="tier">Tier 6</option>
                      <option value="7" name="tier">Tier 7</option>
                      <option value="8" name="tier">Tier 8</option>
                      
                    </select>
                  </div>
                </div>
                <div class="mb-3 pb-2">
                    <label class="form-label" for="unp-product-name">Product Label</label>
                    <input class="form-control" type="text"  name="label">
                  </div>
                    <div class="file-drop-area mb-3">
                    <div class="file-drop-icon ci-cloud-upload"></div><span class="file-drop-message">Drag and drop here to upload Banner Image</span>
                    <input class="file-drop-input" type="file" name="banner">
                    <button class="file-drop-btn btn btn-primary btn-sm mb-2" type="button">Or select file</button>
                  </div>
                  <div class="mb-3 py-2">
                    <label class="form-label" for="unp-product-description">Product description</label>
                    <textarea class="form-control" rows="6" id="unp-product-description" name="description"></textarea>
                    <div class="bg-secondary p-3 fs-ms rounded-bottom"><span class="d-inline-block fw-medium me-2 my-1">Markdown is not supported:</span><del class="d-inline-block border-end pe-2 me-2 my-1" style="">*Italic*</del>
                    <del class="d-inline-block border-end pe-2 me-2 my-1">**Bold**</del><del class="d-inline-block border-end pe-2 me-2 my-1">- List item</del><del class="d-inline-block border-end pe-2 me-2 my-1">##Heading##</del>
                    <del class="d-inline-block">--- Horizontal rule</del></div>
                  </div>
                  <div class="row">
                    <div class="col-sm-6 mb-3">
                      <label class="form-label" for="unp-standard-price">CountDown</label>
                      <div class="input-group"><span class="input-group-text"><i class="ci">! < 20</i></span>
                        <input class="form-control" type="text" id="unp-standard-price" name="countDown">
                      </div>
                      <div class="form-text">Amount of poeple to invest in the contract</div>
                    </div>
                    <div class="col-sm-6 mb-3">
                      <label class="form-label" for="unp-extended-price">Minimum Duration of week</label>
                      <div class="input-group"><span class="input-group-text"><i class="ci-">! < 6</i></span>
                        <input class="form-control" type="text" id="unp-extended-price" name="min_duration">
                      </div>
                      <div class="form-text">Minimum days for the investment duration</div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-sm-6 mb-3">
                      <label class="form-label" for="unp-standard-price">Farm Type</label>
                      <div class="input-group"><span class="input-group-text"><i class="ci">e.g Poutry</i></span>
                        <input class="form-control" type="text" id="unp-standard-price" name="farmType">
                      </div>
                      <div class="form-text">The type of farm contract.</div>
                    </div>
                    <div class="col-sm-6 mb-3">
                      <label class="form-label" for="unp-extended-price">Product group name</label>
                      <div class="input-group"><span class="input-group-text"><i class="ci-">e.g eggs</i></span>
                        <input class="form-control" type="text" id="unp-extended-price" name="family">
                      </div>
                      <div class="form-text">The family name of the farm contract type</div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-sm-6 mb-3">
                      <label class="form-label" for="unp-standard-price">Lowest Bid</label>
                      <div class="input-group"><span class="input-group-text"><i class="ci">NG</i></span>
                        <input class="form-control" type="text" id="unp-standard-price" name="lowestBid">
                      </div>
                      <div class="form-text">Lowest investment price for this post.</div>
                    </div>
                    <div class="col-sm-6 mb-3">
                      <label class="form-label" for="unp-extended-price">Income Percentage</label>
                      <div class="input-group"><span class="input-group-text"><i class="ci-">X</i></span>
                        <input class="form-control" type="text" id="unp-extended-price" name="incomePercentage">
                      </div>
                      <div class="form-text">Munltiplication percentage Like: 1.1 for 10%</div>
                    </div>
                  </div>
                 
                  <div class="mb-3 pb-2">
                    <label class="form-label" for="unp-product-name">Process Algorithm { Open }</label>
                    <input class="form-control" type="text"  name="AlgoOpen">
                  </div> <div class="mb-3 pb-2">
                    <label class="form-label" for="unp-product-name">Process Algorithm { Harvest }</label>
                    <input class="form-control" type="text"  name="AlgoHarvest">
                  </div>
                   <div class="mb-3 pb-2">
                    <label class="form-label" for="unp-product-name">Company Name</label>
                    <input class="form-control" type="text"  name="comapnyName">
                  </div>
                  <div class="mb-3 pb-2">
                    <label class="form-label" for="unp-product-files">Company Logo</label>
                    <input class="form-control" type="file" id="unp-product-files" name="companyLogo">
                    <div class="form-text">Maximum file size is 1GB</div>
                  </div>
                  <button class="btn btn-primary d-block w-100" type="submit"><i class="ci-cloud-upload fs-lg me-2"></i>Upload Product</button>
                </form>
              </div>
            </section>
            </div>
          </div>
        </div>
      </main><?php
  
  require './footer.php';
  }
  ?>
  