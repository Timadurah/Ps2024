
<?php
session_start();
if (empty($_SESSION['KoKOMelon'])) {
    header("Location: ./sign.php");
}
else {
require './materia.php';
require './h2.php';

$servername = "localhost";
$username = "root";
$serverKey = "";
$dbname = "Mr.404";
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $serverKey);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $stmt = $conn->prepare("SELECT * FROM MyGuests WHERE id='".$_SESSION['KoKOMelon']."'");
    $stmt->execute();
    foreach ($stmt as $key) {
      $firstname = $key['firstname'];
      $lastname = $key['lastname'];
      $email = $key['email'];
      $phone = $key['phone'];
      $profile = $key['profile'];
      $date = $key['date'];
    }
?>
<!-- Vendor Styles including: Font Icons, Plugins, etc.-->
    <link rel="stylesheet" media="screen" href="vendor/simplebar/dist/simplebar.min.css"/>
    <link rel="stylesheet" media="screen" href="vendor/tiny-slider/dist/tiny-slider.css"/>
<br>
<br>
<br>
<br>
      <div class="page-title-overlap bg-accent pt-4">
        <div class="container d-flex flex-wrap flex-sm-nowrap justify-content-center justify-content-sm-between align-items-center mb-2 pt-2">
          <div class="d-flex align-items-center">
            <div class="img-thumbnail rounded-circle position-relative flex-shrink-0" style="width: 6.375rem;"><img class="rounded-circle" src="./files/<?=$profile;?>" alt="@foxnet_creator"></div>
            <div class="ps-3">
              <h3 class="h5 mb-2 text-light">@<?=$firstname;?></h3><span class="d-block text-light fs-sm opacity-60">Joined <?=$date;?></span>
            </div>
          </div>
       
        </div>
      </div>
      <div class="container mb-5 pb-3">
        <div class="bg-light shadow-lg rounded-3 overflow-hidden">
          <div class="row">
            <!-- Sidebar-->
           <?php require './aside.php'; ?>
            <!-- Content-->
            <section class="col-lg-9 pt-lg-4 pb-4 mb-3">
              <div class="pt-2 px-4 ps-lg-0 pe-xl-5">
                <h1 class="h3 mb-4 pt-2 text-center text-sm-start">Deposit</h1>
                     <!--  -->
                        

  <div class="accordion mb-2" id="payment-method">
              <div class="accordion-item">
                <h3 class="accordion-header"><a class="accordion-button" href="#card" data-bs-toggle="collapse"><i class="ci-card fs-lg me-2 mt-n1 align-middle"></i>Pay By Transfer</a></h3>
                <div class="accordion-collapse collapse show" id="card" data-bs-parent="#payment-method">
                  <div class="accordion-body">
                    <p class="fs-sm">We accept transfer to secure you bank details:&nbsp;&nbsp;</p>
                    <form class="credit-card-form row" action="./TMS.php" method="POST">
                      <div class="mb-3 col-sm-6">
                        <input class="form-control" type="text" value="<?=$firstname?>" name="TransferName" disabled>
                      </div>
                      <div class="mb-3 col-sm-6">
                        <input class="form-control" type="text" name="name" value="<?=$lastname?>" placeholder="Full Name" disabled>
                      </div>
                      <div class="mb-3 col-sm-3">
                        <input class="form-control" type="email" name="email" value="<?=$email?>"  disabled>
                      </div>
                      <div class="mb-3 col-sm-3">
                        <input class="form-control" type="number" name="FundAmount" placeholder="Amount" required>
                      </div>
                      <div class="col-sm-6">
                        <button class="btn btn-outline-primary d-block w-100 mt-0" type="submit">Fund</button>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
           
            </div>
           
          </section>
         
        </div>



                     <!--  -->
              </div>
            </section>
          </div>
        </div>
      </div>
    </main>


 <!-- Vendor scrits: js libraries and plugins-->
    <script src="vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <script src="vendor/simplebar/dist/simplebar.min.js"></script>
    <script src="vendor/tiny-slider/dist/min/tiny-slider.js"></script>
    <script src="vendor/smooth-scroll/dist/smooth-scroll.polyfills.min.js"></script>
    <script src="vendor/card/dist/card.js"></script>
    <!-- Main theme script-->
    <script src="js/theme.min.js"></script>

    <?php

require './footer.php';
}
?>
