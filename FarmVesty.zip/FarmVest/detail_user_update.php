<?php
$servername = "localhost";
$username = "username";
$serverKey = "password";
$dbname = "mr.404";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $serverKey);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // get info from form
    $fname = $_POST['f_name'];
    $lname = $_POST['l_name'];
    $mail = $_POST['email'];
    $phone = $_POST['phone'];
    if (empty($fname)) {
        $_SESSION['user_detail_response'] = 'First Name is requred';
        }    elseif (empty($lname)) {
                $_SESSION['user_detail_response'] = 'Last Name is requred';
                }
                elseif (empty($mail)) {
                        $_SESSION['user_detail_response'] = 'Mail Address is requred';
                        }   
                        elseif (empty($phone)) {
                            $_SESSION['user_detail_response'] = 'Phone is required!';
                         }
                         else {
    $sql = "UPDATE MyGuests SET firstname=? lastname=? email=? phone=? WHERE id='".$_SESSION['KoKOMelon']."'";
    $stmt->bindParam(':firstname', $fname);
    $stmt->bindParam(':lastname', $lname);
    $stmt->bindParam(':email', $mail);
    $stmt->bindParam(':phone', $phone);
    // Prepare statement
    $stmt = $conn->prepare($sql);
    // execute the query
    $stmt->execute();
    // echo a message to say the UPDATE succeeded
    $_SESSION['user_detail_response'] = " records UPDATED successfully";

                                        }
    }
catch(PDOException $e)
    {
        $_SESSION['user_detail_response'] = "records failed to update.";
    }

$conn = null;
?>