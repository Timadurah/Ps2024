  <!-- Footer-->
  <footer class="footer bg-darker">
     
     
  <div class="container  py-2" style="position:relative; bottom:0px;">
       
      <div class="d-flex flex-md-row flex-column-reverse align-items-center justify-content-md-between">
         
        <div class="fs-xs text-light opacity-50">&copy; All rights reserved. Made by <a class="text-light" href="./" target="_blank" rel="noopener"><?=$uses['companyName'] ?></a></div>
         
          <div class="d-flex align-items-start mb-md-0 mb-3 mx-n1">
           
          <div class="px-1"><a class="btn-market btn-apple bg-dark" href="<?=$uses['ios_app_link'] ?>">
            <span class="btn-market-subtitle">Download on the</span>
          <span class="btn-market-title">App Store</span></a></div>
           
            <div class="px-1"><a class="btn-market btn-google bg-dark" href="<?=$uses['andriod_app_link'] ?>">
                <span class="btn-market-subtitle">Download on the</span>
            <span class="btn-market-title">Google Play</span></a></div>
          </div>
        </div>
      </div>
    </footer>



    <!-- Toolbar for handheld devices (NFT Marketplace)-->
   
    <div class="handheld-toolbar">
     
    <div class="d-table table-layout-fixed w-100"><a class="d-none handheld-toolbar-item" href="#vendor-sidebar" data-bs-toggle="offcanvas">
        <span class="handheld-toolbar-icon"><i class="ci-sign-in"></i></span>
    <span class="handheld-toolbar-label">Sidebar</span></a>

    <a class="d-table-cell handheld-toolbar-item" href="./account-settings.php" data-bs-toggle="modal">
        <span class="handheld-toolbar-icon"><i class="ci-user"></i></span>
    <span class="handheld-toolbar-label">Account</span></a>

    <a class="d-table-cell handheld-toolbar-item" href="./" >
    <span class="handheld-toolbar-icon"><i class="ci-home"></i></span>
    <span class="handheld-toolbar-label">Home</span></a>

    <a class="d-table-cell handheld-toolbar-item" href="./deposit.php">
        <span class="handheld-toolbar-icon"><i class="ci-wallet"></i></span>
    <span class="handheld-toolbar-label text-nowrap">Deposit</span></a>
      </div>
    </div>
    <!-- Vendor scrits: js libraries and plugins-->
    <script src="vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <script src="vendor/simplebar/dist/simplebar.min.js"></script>
    <script src="vendor/tiny-slider/dist/min/tiny-slider.js"></script>
    <script src="vendor/smooth-scroll/dist/smooth-scroll.polyfills.min.js"></script>
    <!-- Main theme script-->
    <script src="js/theme.min.js"></script>
    <script src="./js/behaviour.js"></script>
  </body>

</html>