<?php
session_start();
$servername = "localhost";
$username = "root";
$serverKey = "";
$dbname = "Mr.404";

$conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $serverKey);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$mail_ = strip_tags($_SESSION['fg_mail']);
  if (empty($_POST['Verification'])) {
    $_SESSION['otp__response'] = 'Verification Code is requred';
         }
         elseif (empty($_POST['new_password'])) {
            $_SESSION['otp__response'] = 'Your new password is requred';
        }
             else {                                     
 
     $stmt = $conn->prepare("SELECT Verivication_code FROM verification_now WHERE mail='".$mail_."'");
    $stmt->execute();
   foreach ($stmt as $key) {
    if ($key['Verivication_code'] == $_POST['Verification']) {
    $_SESSION['otp__response'] = null;   
    // hash the password  
    $refine_paasword = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
    $sqly = "UPDATE myguests SET passwd='".$refine_paasword."' WHERE email='".$mail_."'";
    // Prepare statement
    $stmt = $conn->prepare($sqly);
    // execute the query
    $stmt->execute();  
    // sql to delete a record
    $sql = "DELETE FROM verification_now WHERE mail='".$mail_."'";
    // use exec() because no results are returned
    $conn->exec($sql);
    header("Location: ./done.php");
    }
    else{
      $_SESSION['otp__response'] = 'Incorrect Verification Code.';
      header("Location: ./account-password-recovery_otp.php");
    }   
}

$conn = null;
}
?>