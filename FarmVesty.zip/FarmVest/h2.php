<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<head>
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
    <meta charset="utf-8">
    <title><?=$uses['companyName'] ?> | <?=$uses['companyType'] ?></title>
    <!-- SEO Meta Tags-->
    <meta name="description" content="<?=$uses['companyKeyword'] ?>">
    <meta name="keywords" content="<?=$uses['companyKeyword'] ?>">
    <meta name="author" content="<?=$uses['companyName'] ?>">
    <!-- Viewport-->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon and Touch Icons-->
    <link rel="apple-touch-icon" sizes="180x180" href="apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="favicon-16x16.png">
    <link rel="manifest" href="site.webmanifest">
    <link rel="mask-icon" color="#fe6a6a" href="safari-pinned-tab.svg">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="theme-color" content="#ffffff">
    <!-- Vendor Styles including: Font Icons, Plugins, etc.-->
    <link rel="stylesheet" media="screen" href="vendor/simplebar/dist/simplebar.min.css"/>
    <link rel="stylesheet" media="screen" href="vendor/tiny-slider/dist/tiny-slider.css"/>
    <!-- Main Theme Styles + Bootstrap-->
    <link rel="stylesheet" media="screen" href="css/theme.min.css">
    <!-- custom css -->
    <style type="text/css">
      h1, h2, h3, h4, a, p, div, button,input{
        font-family: monospace;
      }
    </style>
<link rel="stylesheet" type="text/css" href="./Csy.css">
  </head>
  <!-- Body-->
  <body class="handheld-toolbar-enabled" >
  
    <main class="page-wrapper"  style="background: #fff !important;" >
      <!-- Navbar for NFT Marketplace demo-->
      <!-- Remove "navbar-sticky" class to make navigation bar scrollable with the page.-->
      <header class="navbar d-block navbar-sticky navbar-expand-lg navbar-light position-absolute w-100" >
        <div class="container"><a class="navbar-brand d-none d-sm-block me-4 order-lg-1" href="./"><img src="img/<?=$uses['companyLogo'] ?>" width="74" alt="<?=$uses['companyName'] ?>"></a><a class="navbar-brand d-sm-none me-2 order-lg-1" href="./"><img src="img/<?=$uses['companyLogo'] ?>" width="74" alt="<?=$uses['companyName'] ?>"></a>
          <div class="navbar-toolbar d-flex align-items-center order-lg-3">
              <a class="navbar-tool ms-lg-2" href="./account-settings.php" data-bs-toggle="modal"><span class="navbar-tool-tooltip">Account</span>
              <div class="navbar-tool-icon-box shadow" style="border-radius: 20px; "><i class="navbar-tool-icon ci-user"></i></div></a>
          </div>
          <div class="collapse navbar-collapse me-auto order-lg-2" id="navbarCollapse">
            <!-- Search (mobile)-->
            <div class="d-lg-none py-3">
              <div class="input-group"><i class="ci-search position-absolute top-50 start-0 translate-middle-y ms-3"></i>
                <input class="form-control rounded-start" type="text" placeholder="What do you need?">
              </div>
            </div>
            <!-- Primary menu-->
            <ul class="navbar-nav"  style="font-family: monospace;">
              <li class="nav-item active"><a class="nav-link" href="./">Home</a></li>
              <li class="nav-item dropdown"><a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">Account</a>
                <ul class="dropdown-menu">
                  <li><a class="dropdown-item" href="account-settings.php">Profile Settings</a></li>
                  <li><a class="dropdown-item" href="my_invest.php">My Investment</a></li>
                  <li><a class="dropdown-item" href="./deposit.php">Deposit</a></li>
                  <li><a class="dropdown-item" href="./my_withdraw.php">Withdraw</a></li>
                  <li><a class="dropdown-item" href="./bonus.php">Bonus</a></li>
                  <li><a class="dropdown-item" href="./Transaction_history.php">Transaction history</a></li>
                </ul>
              </li>
              <li class="nav-item"><a class="nav-link" href="./my_invest.php">My Investment</a></li>
              <li class="nav-item"><a class="nav-link" href="./my_withdraw.php">Withdraw</a></li>
              <li class="nav-item"><a class="nav-link" href="./about_us.php">About Us</a></li>
              <li class="nav-item"><a class="nav-link" href="./faq.php">FAQ</a></li>
            </ul>
          </div>
        </div>
        <!-- Search collapse-->
        <div class="search-box collapse" id="searchBox">
          <div class="container py-2">
            <div class="input-group"><i class="ci-search position-absolute top-50 start-0 translate-middle-y ms-3"></i>
              <input class="form-control rounded-start" type="text" placeholder="What do you need?">
            </div>
          </div>
        </div>
      </header>
