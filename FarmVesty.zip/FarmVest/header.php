
<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
    <meta charset="utf-8">
    <title><?=$uses['companyName'] ?> | <?=$uses['companyType'] ?></title>
    <!-- SEO Meta Tags-->
    <meta name="description" content="<?=$uses['companyKeyword'] ?>">
    <meta name="keywords" content="<?=$uses['companyKeyword'] ?>">
    <meta name="author" content="<?=$uses['companyName'] ?>">
    <!-- Viewport-->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon and Touch Icons-->
    <link rel="apple-touch-icon" sizes="180x180" href="apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="favicon-16x16.png">
    <link rel="manifest" href="site.webmanifest">
    <link rel="mask-icon" color="#fe6a6a" href="safari-pinned-tab.svg">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="theme-color" content="#ffffff">
    <!-- Vendor Styles including: Font Icons, Plugins, etc.-->
    <link rel="stylesheet" media="screen" href="vendor/simplebar/dist/simplebar.min.css"/>
    <link rel="stylesheet" media="screen" href="vendor/tiny-slider/dist/tiny-slider.css"/>
    <!-- Main Theme Styles + Bootstrap-->
    <link rel="stylesheet" media="screen" href="css/theme.min.css"/>
    <link rel="stylesheet" href="./css/anima.css">
  </head>
  <!-- Body-->
  <body class="handheld-toolbar-enabled" style="background: #fff !important; ">
  <main class="page-wrapper">
<?php
if (empty($_SESSION['JJC'])) {
    @$_SESSION['JJC'] = 'Arrived';
?>

  <!-- preload -->
  <div class="loadery"  id="flyout" >
  <div class="loader_">
  <span></span>
  <span></span>
  <span></span>
  <span></span>
</div>
</div>

<?php
}
?>
    
