<?php
session_start();
if (empty($_SESSION['KoKOMelon'])) {
    header("Location: ./sign.php");
}
else {
require './materia.php';
require './h2.php';



?>



    <main class="page-wrapper">
      <!-- Navbar for NFT Marketplace demo-->
      <!-- Remove "navbar-sticky" class to make navigation bar scrollable with the page.-->
   <?php
$servername = "localhost";
$username = "root";
$serverKey = "";
$dbname = "Mr.404";
 
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $serverKey);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $stmt = $conn->prepare("SELECT * FROM availableinvestment WHERE tier='5'");
    $stmt->execute();
    foreach ($stmt as $key) {
    	$token_id = $key['Token_ID'];
    	$label = $key['label'];
    	$banner = $key['banner'];
    	$countdown = $key['countdown'];
    	$description = $key['description'];
    	$companyName = $key['companyName'];
    	$companyLogo = $key['companyLogo'];
    	$currentBid = $key['currentBid'];
    	$incomePercentage = $key['incomePercentage'];
    	$min_duration = $key['min_duration'];

    }
?>
      <!-- Hero-->
      <section class="mb-lg-2 bg-size-cover" style="padding-top: 80px;">
        <div class="container py-4">
          <div class="row align-items-center justify-content-center gy-3 py-3 text-lg-start text-center">
            <div class="col-lg-5 col-md-8 col-sm-10">
              <h3 class="mb-4 pb-lg-2 fw-bold"  style="font-family: monospace;">Invest through a crowdfunding platform focused on farming</h3>
              <p class="mb-lg-5 mb-4 fs-lg"  style="font-family: monospace;">
                
"<?=$uses['companyName'];?>" is a pioneering online platform connecting investors with sustainable agricultural opportunities. With us, investors gain access to diverse farming projects, allowing them to invest in crops, livestock, and sustainable farming practices. Our platform offers transparent tracking tools, enabling investors to monitor their investments' growth and impact in real-time. Join us to sow the seeds of your investments and reap sustainable returns while fostering the future of agriculture.


              </p>
              <div class="d-lg-flex d-none flex-sm-row flex-column justify-content-lg-start justify-content-center"><a class="btn btn-lg btn-dark mb-sm-3 mb-2" href="./single-auction.php?Token=<?=$token_id?>">Make More</a></div>
            </div>






            <div class="col-lg-6 col-md-8 offset-lg-1 col-sm-10 ajk">
              <!-- Top auctions carousel-->
              <div class="mb-4 mx-n2">
                  <!-- Carousel item-->
                  <div class="px-2" ><img class="rounded-3" src="./<?=$banner;?>" alt="Product" style="min-height: 500px;">
                    <div class="position-relative">
                      <div class="position-absolute start-0 bottom-0 w-100 p-md-5 p-sm-4 p-3">
                        <div class="pt-sm-0 pt-2 px-sm-4 px-2 bg-white rounded shadow">
                          <div class="row gx-5">
                            <div class="col-sm-3 col-6 position-relative py-sm-3 py-2">
                              <h6 class="mb-1 fs-sm fw-small text-muted">MiniMum Price:</h6><small class="h7 mb-0"><?=$currentBid;?>.00 NG</small>
                            </div>
                            <div class="col-sm-5 col-6 position-relative py-sm-3 py-2">
                              <hr class="hr-vertical position-absolute start-0 top-0 ml-n4">
                              <h6 class="mb-1 fs-sm fw-normal text-muted">Make:</h6><small class="h7 mb-0"><?=$currentBid * $incomePercentage;?> i.e 50% In <?=$min_duration;?> days</small>
                            </div>
                            <div class="col-sm-4 position-relative py-sm-3 py-2">
                              <hr class="hr-vertical position-absolute start-0 top-0 ml-n4 d-sm-block d-none">
                              <div class="d-flex align-items-center h-100"><a class="btn btn-sm btn-dark w-100" href="./single-auction.php?Token=<?=$token_id;?>">Invest Now!</a></div>
                            </div>
                        </div>
                      </div>
                    </div>
                  </div>
                 
                </div>
              </div>
             
            </div>
          </div>
        </div>
      </section>
      <!-- Product carousel (Recent Drops)-->
      <section class="container mb-2 py-lg-5 py-4">
        <div class="d-flex align-items-center justify-content-between mb-sm-3 mb-2">
          <h2 class="h3 mb-0 fw-bold">Available Packages</h2>

        </div>
        <hr>
      <br>
        <div class="row justify-content-center row-cols-lg-4 row-cols-md-3 row-cols-sm-2 row-cols-1 gy-sm-4 gy-3 pt-lg-4 pt-2">
         
<?php
$Home_invests = $conn->prepare("SELECT * FROM availableinvestment ORDER BY id DESC");
    $Home_invests->execute();
    foreach ($Home_invests as $key_invests) {
    	$token_id_list = $key_invests['Token_ID'];
    	$label_list = $key_invests['label'];
    	$banner_list = $key_invests['banner'];
    	$countdown_list = $key_invests['countdown'];
    	$description_list = $key_invests['description'];
    	$companyName_list = $key_invests['companyName'];
    	$companyLogo_list = $key_invests['companyLogo'];
    	$currentBid_list = $key_invests['currentBid'];
    	$incomePercentage_list = $key_invests['incomePercentage'];
    	$min_duration_list = $key_invests['min_duration'];

   ?>


          <!-- Product-->
          <div class="col mb-2">
            <article class="card h-100 border-0 shadow">
              <div class="card-img-top position-relative overflow-hidden"><a class="d-block" href="./single-auction.php?Token=<?=$token_id_list;?>"><img src="./<?=$banner_list;?>" alt="Product image" class="justify-content-center align-items-center d-flex"></a>        
                            </div>
              <div class="card-body">
                <h3 class="product-title mb-2 fs-base"  style="font-family: monospace;"><a class="d-block text-truncate text-muted fw-bold" href="./single-auction.php?Token=<?=$token_id_list;?>"><?=$label_list;?></a></h3><span class="fs-sm text-muted">Minimum Price:</span>
                <div class="d-flex align-items-center flex-wrap">
                 <span class="mt-1 ms-1 fs-xs text-muted"  style="font-family: monospace;"><?=$currentBid_list;?> NG @ <?=$incomePercentage_list * 100 - 100;?>% = </span><h4 class="mt-1 px-1 mb-0 fs-base text-darker" style="font-family: monospace;"> <?=$currentBid_list * $incomePercentage_list;?> NG</h4>
                </div>
                <span class="fs-sm text-muted">In <?=$min_duration_list;?> days</span>
              </div>
              <div class="card-footer mt-n1 py-0 border-0">
                <div class="d-flex align-items-center position-relative mb-1 py-3 border-top"><img class="me-2 rounded-circle" src="./<?=$companyLogo_list;?>" width="32" alt="Avatar"><a class="nav-link-style fs-sm stretched-link" href="./single-auction.php?Token=<?=$token_id_list;?>"  style="font-family: monospace;">@<?=$companyName_list;?></a></div>
              </div>
            </article>
          </div>
         <?php
          }

    ?>



        </div>
        </section>
    </main>


<?php
require './footer.php';
}
?>