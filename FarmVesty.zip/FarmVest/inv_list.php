
<?php
session_start();
if ($_SESSION['pussy'] !== 'ps2024') {
  header("location: ./smile.php");
}
else{
  require './materia.php';
  require './h2.php';
  
$servername = "localhost";
$username = "root";
$serverKey = "";
$dbname = "Mr.404";
 
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $serverKey);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
   
  ?>
  <br>
  <br>
  <br>
  <br>
        
        <div class="container mb-5 pb-3">
          <div class="bg-light shadow-lg rounded-3 overflow-hidden">
            <div class="row">
              <!-- Sidebar-->
             <?php require './asideTopussy.php'; ?>
              <!-- Content-->
              <section class="col-lg-9 pt-lg-4 pb-4 mb-3">
                <div class="pt-2 px-4 ps-lg-0 pe-xl-5">
  
  <?php
  
  $Home_invests = $conn->prepare("SELECT * FROM availableinvestment");
  $Home_invests->execute();
  $counter = $Home_invests->rowCount();
  ?>
                 
                <i><h3 class="h4 mb-4 pt-2 text-center text-sm-start"><?=$counter;?> Investments</h3></i>
                
                <div class="row row-cols-lg-4 row-cols-md-3 row-cols-sm-2 row-cols-1 gy-sm-4 gy-3 pt-lg-4 pt-2">
         
         <?php
        
             foreach ($Home_invests as $key_invests) {
               $token_id_list = $key_invests['Token_ID'];
               $label_list = $key_invests['label'];
               $banner_list = $key_invests['banner'];
               $countdown_list = $key_invests['countdown'];
               $description_list = $key_invests['description'];
               $companyName_list = $key_invests['companyName'];
               $companyLogo_list = $key_invests['companyLogo'];
               $currentBid_list = $key_invests['currentBid'];
               $incomePercentage_list = $key_invests['incomePercentage'];
               $min_duration_list = $key_invests['min_duration'];
         
            ?>
         
         
                   <!-- Product-->
                   <div class="col mb-2">
                     <article class="card h-100 border-0 shadow">
                       <div class="card-img-top position-relative overflow-hidden"><a class="d-block" href="./single-auction.php?Token=<?=$token_id_list;?>"><img src="./<?=$banner_list;?>" alt="Product image"></a>        
                                     </div>
                       <div class="card-body">
                         <h3 class="product-title mb-2 fs-base"><a class="d-block text-truncate" href="./single-auction.php?Token=<?=$token_id_list;?>"><?=$label_list;?></a></h3><span class="fs-sm text-muted">Minimum Price:</span>
                         <div class="d-flex align-items-center flex-wrap">
                           <h4 class="mt-1 mb-0 fs-base text-darker"><?=$currentBid_list;?> NG</h4><span class="mt-1 ms-1 fs-xs text-muted"> @ <?=$incomePercentage_list * 100 - 100;?>% (= # <?=$currentBid_list * $incomePercentage_list;?>)</span>
                         </div>
                         <span class="fs-sm text-muted">In <?=$min_duration_list;?> days</span>
                       </div>
                       <div class="card-footer mt-n1 py-0 border-0">
                         <div class="d-flex align-items-center position-relative mb-1 py-3 border-top"><img class="me-2 rounded-circle" src="./<?=$companyLogo_list;?>" width="32" alt="Avatar"><a class="nav-link-style fs-sm stretched-link" href="./single-auction.php?Token=<?=$token_id_list;?>">@<?=$companyName_list;?></a></div>
                       </div>
                     </article>
                   </div>
                  <?php
                   }
         
             ?>
         
         
         
                 </div>



                </div>
              </section>
            </div>
          </div>
        </div>
      </main><?php
  
  require './footer.php';
  }
  ?>
  