<?php
session_start();
$servername = "localhost";
$username = "root";
$serverKey = "";
$dbname = "mr.404";
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $serverKey);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        //cehck if the balance will reach 
  $balancey = $conn->prepare("SELECT * FROM balance WHERE user_id=".$_SESSION['KoKOMelon']."");
  $balancey->execute();
  foreach ($balancey as $key) {
    $balance_in_now = $key['balance'];
  }
  
 if ($_POST['amount'] < $_SESSION['currentBid']) {
    $_SESSION['invest_respondi'] = '<p style="color:pink;">The minimum amount for this investment is '.$_SESSION['currentBid'].' NG</p>';
    header("location: ./single-auction.php?Token=".$_SESSION['token_ids']."");
  }
  elseif ($_POST['amount'] > $balance_in_now) {
    $_SESSION['invest_respondi'] = '<p style="color:pink;">Your is too low to make this investmet <a href="./deposit.php" style="color:lightgreen;">Add Money</a></p>';
    header("location: ./single-auction.php?Token=".$_SESSION['token_ids']."");
  }
  else {
    $sub = $conn->prepare("INSERT INTO `invest`(`invest_Adress`, `investor_id`, `amount`, `duration`) 
    VALUES ('".$_SESSION['token_ids']."','".$_SESSION['KoKOMelon']."','".$_POST['amount']."','".$_POST['duration']."')");
    $sub->execute();
    $_SESSION['invest_respondi'] = '<p style="color:lightgreen;">Successfully Invested</p>';
    $_SESSION['invest_respondi_c'] = 1;
  }

