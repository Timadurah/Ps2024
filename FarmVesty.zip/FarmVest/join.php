<?php
session_start();
require './materia.php';
$servername = "localhost";
$username = "root";
$serverKey = "";
$dbname = "Mr.404";


    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $serverKey);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    // get info from form
    $fname = $_POST['f_name'];
    $lname = $_POST['l_name'];
    $mail = $_POST['email'];
    $password = $_POST['password'];
    $phone = $_POST['phone'];
    $c_password = $_POST['c_password'];
    $profile = 'avatar.png';

    // condition 
    if ($password !== $c_password) {
            $_SESSION['join_response'] = 'Password is not the same';
    header("Location: ./");

    }
    elseif (empty($fname)) {
            $_SESSION['join_response'] = 'First Name is requred!';
    header("Location: ./");

            }    elseif (empty($lname)) {
                    
                    $_SESSION['join_response'] = 'Last Name is requred!';
    header("Location: ./");

                    }
                    elseif (empty($mail)) {
                            
                            $_SESSION['join_response'] = 'Mail Address is requred';
    header("Location: ./");

                            }    elseif (empty($password)) {
                                    
                                    $_SESSION['join_response'] = 'Password Key NEED to be create!';
    header("Location: ./");

                                    }    elseif (empty($c_password)) {
                                            
                                            $_SESSION['join_response'] = 'Password key need to be confirm correctly!';
    header("Location: ./");

                                            }   
                                                elseif (empty($phone)) {
                                                   
                                                   $_SESSION['join_response'] = 'Phone is required!';
    header("Location: ./");

                                                }
                                            else {
// check email availability


                                                 $ch__ = $conn->prepare("SELECT id FROM MyGuests WHERE email='".$mail."'");
                                                     $ch__->execute();
                                                     $ch_Count = $ch__->rowCount();                             if ($ch_Count < 1) {
                                        
                                   
                                                // hashing the password


                                                $refine_paasword = password_hash($password, PASSWORD_DEFAULT);
                                                
    // our SQL statements
    $stmt = $conn->prepare("INSERT INTO MyGuests (firstname, lastname, email, phone, profile, passwd)
    VALUES (:firstname, :lastname, :email, :phone, :profile, :passwd)");
    // bind the data
    $stmt->bindParam(':firstname', $fname);
    $stmt->bindParam(':lastname', $lname);
    $stmt->bindParam(':email', $mail);
    $stmt->bindParam(':phone', $phone);
    $stmt->bindParam(':profile', $profile);
    $stmt->bindParam(':passwd', $refine_paasword);
    // commit the transaction
    $stmt->execute();
    $ids = $conn->lastInsertId();
    $_SESSION['KoKOMelon'] =  $conn->lastInsertId();

//     insert into Balance 
$balan = $conn->prepare("INSERT INTO legalbalance (user_id, balance)
VALUES (:user_id, :balance)");
$user_id = $ids;
$balance = 0;
// bind the data
$balan->bindParam(':user_id', $user_id);
$balan->bindParam(':balance', $balance);
// commit the transaction
$balan->execute();

//     insert into Welcome Bonus 
$WelcomeBonus = $conn->prepare("INSERT INTO WelcomeBonus (user_id, balance)
VALUES (:user_id, :balance)");
// bind the data
$WelcomeBonus->bindParam(':user_id', $user_id);
$WelcomeBonus->bindParam(':balance', $uses['welcomebonus']);
// commit the transaction
$WelcomeBonus->execute();



                       
// get legabalance den add up to update
$xyw = $conn->prepare("SELECT * FROM legalbalance WHERE user_id=".$ids."");
                                                     $xyw->execute(); 
                                                     foreach ($xyw as $fff) {
                                                        $balancebooky = $fff['balance'];
                                                     }
$bn0 = $uses['welcomebonus'] + $balancebooky;
$legalBalancey = $conn->prepare("UPDATE legalbalance SET balance=".$bn0." WHERE user_id=".$ids."");
// commit the transaction
$legalBalancey->execute();


if (@$_SESSION['ref'] !== null) {
//     insert into referal 
$refra = $conn->prepare("INSERT INTO bonus (refer, referal)
VALUES (:refer, :referal)");
$refer = $mail;
$referal = $_SESSION['ref'];
// bind the data
$refra->bindParam(':refer', $refer);
$refra->bindParam(':referal', $referal);
// commit the transaction
$refra->execute();

// get referL ID
$ch__l = $conn->prepare("SELECT id FROM MyGuests WHERE email='".$referal."'");
                                                     $ch__l->execute(); 
                                                     foreach ($ch__l as $kekeh) {
                                                        $idskey = $kekeh['id'];
                                                     }
                               
// get legabalance den add up to update
$ch__legb = $conn->prepare("SELECT * FROM legalbalance WHERE user_id='".$idskey."'");
                                                     $ch__legb->execute(); 
                                                     foreach ($ch__legb as $baly) {
                                                        $balancebook = $baly['balance'];
                                                     }
$bn = $uses['referalBonus'] + $balancebook;
$legalBalance = $conn->prepare("UPDATE legalbalance SET balance=".$bn." WHERE user_id=".$idskey."");
// commit the transaction
$legalBalance->execute();


}

    $_SESSION['ref'] = null;
    $_SESSION['join_response'] = null;
    header("Location: ./");
}
else{
        $_SESSION['join_response'] = "Email already exist";
    header("Location: ./");
}
}
$conn = null;
?>
