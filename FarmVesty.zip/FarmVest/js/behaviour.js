setTimeout(() => {
    document.getElementById("flyout").style.display="none";
}, 5000);