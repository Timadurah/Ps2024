<?php
session_start();
$servername = "localhost";
$username = "root";
$serverKey = "";
$dbname = "Mr.404";

    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $serverKey);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
// datas
$mail = $_POST['email'];
$password = $_POST['password'];
  if (empty($mail)) {
    $_SESSION['login_response'] = 'Mail Address is requred';
    header("Location: ./");

         }elseif ( empty($password)) {
               $_SESSION['login_response'] = 'Password is requred';
    header("Location: ./");

                    }
                    else {
                        
                    
try {
    $stmt = $conn->prepare("SELECT id, passwd FROM MyGuests WHERE email='".$mail."'");
    $stmt->execute();
   foreach ($stmt as $key) {
    if (password_verify($password, $key['passwd'])) {
        # login is true
        $_SESSION['KoKOMelon'] = $key['id'];
        $_SESSION['login_response'] = null;
        header("Location: ./");
    }
    else{
        $_SESSION['login_response'] = 'Password Or Mail is incorrect';
    header("Location: ./");


    }
}
}
catch(PDOException $e) {
    $_SESSION['login_response'] = 'Password Or Mail is incorrect';
    header("Location: ./");
    
}
$conn = null;
}
?>