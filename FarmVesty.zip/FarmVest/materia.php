<?php


$uses  = array('companyName' => 'FarmFirm',
                'companyType' => 'Fvt, Agricultural Investment Inc',
                'companyDescription' => 'You invest, we use your money to do business and return your profit within small period of time.',
                'companyKeyword' => 'Joing the world of intrepreneur and turn your little cash to usefull amount of money within some days of investment',
                'companyLogo' => 'logo-icon.png',
                'andriod_app_link' => '',
                'ios_app_link' => '',
                'referalBonus' => 1500,
                'welcomebonus' => 500
 );

?>