-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 28, 2023 at 06:38 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mr.404`
--

-- --------------------------------------------------------

--
-- Table structure for table `availableinvestment`
--

CREATE TABLE `availableinvestment` (
  `id` int(11) NOT NULL,
  `label` varchar(255) COLLATE utf8_bin NOT NULL,
  `banner` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `farmType` varchar(250) COLLATE utf8_bin NOT NULL,
  `countdown` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `companyName` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `companyLogo` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `currentBid` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `incomePercentage` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `tier` int(10) NOT NULL,
  `Contract_Address` varchar(225) COLLATE utf8_bin NOT NULL,
  `Token_ID` varchar(225) COLLATE utf8_bin NOT NULL,
  `Token_Standard` varchar(225) COLLATE utf8_bin NOT NULL,
  `Family` varchar(225) COLLATE utf8_bin NOT NULL,
  `min_duration` varchar(225) COLLATE utf8_bin NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `availableinvestment`
--

INSERT INTO `availableinvestment` (`id`, `label`, `banner`, `farmType`, `countdown`, `description`, `companyName`, `companyLogo`, `currentBid`, `incomePercentage`, `tier`, `Contract_Address`, `Token_ID`, `Token_Standard`, `Family`, `min_duration`, `date`) VALUES
(10, 'Microsoft account unusual sign-in activities', 'files/04.jpg', 'Rabbits', '200', 'Markdown Markdown Markdown Markdown Markdown Markdown Markdown Markdown Markdown Markdown Markdown Markdown Markdown Markdown Markdown Markdown Markdown Markdown Markdown Markdown Markdown Markdown Markdown Markdown Markdown Markdown Markdown Markdown Mar', 'RabitRoyLand', 'files/05.jpg', '20000', '1.55', 5, '0x1d5s-729372937293', '938372938372938372938372938372', 'FXK-729', 'Urines', '14', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `balance`
--

CREATE TABLE `balance` (
  `user_id` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `balance` varchar(255) COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `balance`
--

INSERT INTO `balance` (`user_id`, `balance`) VALUES
('1', '60000');

-- --------------------------------------------------------

--
-- Table structure for table `bonus`
--

CREATE TABLE `bonus` (
  `refer` varchar(100) COLLATE utf8_bin NOT NULL,
  `referal` varchar(100) COLLATE utf8_bin NOT NULL,
  `id` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `bonus`
--

INSERT INTO `bonus` (`refer`, `referal`, `id`, `date`) VALUES
('Dev@Scimail.com', 'ourfarmdatabase@gmail.com', 1, '2023-11-27 22:27:55'),
('rechealMeary@gmail.com', 'ourfarmdatabase@gmail.com', 2, '2023-11-27 22:42:25');

-- --------------------------------------------------------

--
-- Table structure for table `invest`
--

CREATE TABLE `invest` (
  `id` int(255) NOT NULL,
  `invest_Adress` varchar(255) COLLATE utf8_bin NOT NULL,
  `investor_id` varchar(255) COLLATE utf8_bin NOT NULL,
  `amount` varchar(255) COLLATE utf8_bin NOT NULL,
  `duration` varchar(255) COLLATE utf8_bin NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `myguests`
--

CREATE TABLE `myguests` (
  `id` int(11) NOT NULL,
  `firstname` varchar(255) COLLATE utf8_bin NOT NULL,
  `lastname` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `profile` text COLLATE utf8_bin NOT NULL,
  `passwd` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `myguests`
--

INSERT INTO `myguests` (`id`, `firstname`, `lastname`, `email`, `phone`, `profile`, `passwd`, `date`) VALUES
(3, 'Ademola', 'Aduragbemi', 'ourfarmdatabase@gmail.com', '+2349051547147', 'avatar.png', '$2y$10$b5EQTqg0jb0Qhr9ENkoRduXxRLPvOq4impnLJU07JPXFfmyB11LnW', '2023-11-23 16:23:18'),
(4, 'Ademola', 'Aduragbemi', 'Dev@Scimail.com', 'Remake', 'avatar.png', '$2y$10$5MN1gs0mPjgEeKBwsXYTPe94KgUEF7m.at4c7iTm1Yw6BtzlXOAo2', '2023-11-27 22:21:44'),
(6, 'Princess', 'Meary', 'rechealMeary@gmail.com', '07026626851', 'avatar.png', '$2y$10$nhKkLlTPIS/tJS/rAOzID.hH.po1uCjWdGxYjtefdoPgA8BTgwwkC', '2023-11-27 22:42:25');

-- --------------------------------------------------------

--
-- Table structure for table `verification_now`
--

CREATE TABLE `verification_now` (
  `mail` varchar(100) COLLATE utf8_bin NOT NULL,
  `Verivication_code` varchar(7) COLLATE utf8_bin NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `availableinvestment`
--
ALTER TABLE `availableinvestment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bonus`
--
ALTER TABLE `bonus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `invest`
--
ALTER TABLE `invest`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `myguests`
--
ALTER TABLE `myguests`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `availableinvestment`
--
ALTER TABLE `availableinvestment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `bonus`
--
ALTER TABLE `bonus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `invest`
--
ALTER TABLE `invest`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `myguests`
--
ALTER TABLE `myguests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
