
<?php
session_start();
if (empty($_SESSION['KoKOMelon'])) {
    header("Location: ./sign.php");
}
else {
require './materia.php';
require './h2.php';

$servername = "localhost";
$username = "root";
$serverKey = "";
$dbname = "Mr.404";
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $serverKey);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $stmt = $conn->prepare("SELECT * FROM MyGuests WHERE id='".$_SESSION['KoKOMelon']."'");
    $stmt->execute();
    foreach ($stmt as $key) {
      $firstname = $key['firstname'];
      $lastname = $key['lastname'];
      $email = $key['email'];
      $phone = $key['phone'];
      $profile = $key['profile'];
      $date = $key['date'];
    }
?>
<br>
<br>
<br>
<br>
      <div class="page-title-overlap bg-accent pt-4">
        <div class="container d-flex flex-wrap flex-sm-nowrap justify-content-center justify-content-sm-between align-items-center mb-2 pt-2">
          <div class="d-flex align-items-center">
            <div class="img-thumbnail rounded-circle position-relative flex-shrink-0" style="width: 6.375rem;"><img class="rounded-circle" src="./files/<?=$profile;?>" alt="@foxnet_creator"></div>
            <div class="ps-3">
              <h3 class="h5 mb-2 text-light">@<?=$firstname;?></h3><span class="d-block text-light fs-sm opacity-60">Joined <?=$date;?></span>
            </div>
          </div>
       
        </div>
      </div>
      <div class="container mb-5 pb-3">
        <div class="bg-light shadow-lg rounded-3 overflow-hidden">
          <div class="row">
            <!-- Sidebar-->
           <?php require './aside.php'; ?>
            <!-- Content-->
            <section class="col-lg-9 pt-lg-4 pb-4 mb-3">
              <div class="pt-2 px-4 ps-lg-0 pe-xl-5">
                <h1 class="h3 mb-4 pt-2 text-center text-sm-start">My investments</h1>

                <hr>
                <br>
                   <div class="row row-cols-md-3 row-cols-sm-2 row-cols-1 gy-sm-4 gy-3 gx-3 mb-4">


<?php

$erry = $conn->prepare("SELECT * FROM invest WHERE investor_id='".$_SESSION['KoKOMelon']."'");
$erry->execute();
$counter = $erry->rowCount();
if ($counter < 1) {
  echo '<h1 class="text-warning">NO investment for you.</h1>';
}
foreach ($erry as $key) {
$address = $key['invest_Adress'];
$amount = $key['amount'];
$duration = $key['duration'];
$daate = $key['date'];



$Home_invests = $conn->prepare("SELECT * FROM availableinvestment WHERE Token_ID=".$address."");
$Home_invests->execute();
           foreach ($Home_invests as $key_invests) {
             $token_id_list = $key_invests['Token_ID'];
             $label_list = $key_invests['label'];
             $banner_list = $key_invests['banner'];
             $companyName_list = $key_invests['companyName'];
             $companyLogo_list = $key_invests['companyLogo'];
             $currentBid_list = $key_invests['currentBid'];
             $incomePercentage_list = $key_invests['incomePercentage'];
             $min_duration_list = $key_invests['min_duration'];


// write check code here if the investment has been done.


      
if (timeago($daate) == timeago($duration)) {
  echo "you have been funded with your investment";

  // fund account with investment fund
// Calculate the profit of the investment
$profity = $currentBid_list * $incomePercentage_list;

    // get legabalance den add up to update
    $ch__legb = $conn->prepare("SELECT * FROM legalbalance WHERE user_id='".$_SESSION['KoKOMelon']."'");
                                                         $ch__legb->execute(); 
                                                         foreach ($ch__legb as $baly) {
                                                            $balancebook = $baly['balance'];
                                                         }
    $bn = $profity + $balancebook;
    $legalBalance = $conn->prepare("UPDATE legalbalance SET balance=".$bn." WHERE user_id=".$_SESSION['KoKOMelon']."");
    // commit the transaction
    $legalBalance->execute();

}
  function timeago($date) {
     $timestamp = strtotime($date); 
     $length = array("60","60","24","30");

     $currentTime = time();
     if($currentTime >= $timestamp) {
      $diff     = time()- $timestamp;
      for($i = 0; $diff >= $length[$i] && $i < count($length)-1; $i++) {
      $diff = $diff / $length[$i];
      }

      $diff = round($diff);
      return $diff;
     }
  }
  
 

?>
                 



                  <!-- Product-->
                  <div class="col mb-2">
                    <article class="card h-100 border-0 shadow">
                      <div class="card-img-top position-relative overflow-hidden"><a class="d-block" href="nft-single-buy.html"><img src="./<?=$banner_list;?>" alt="Product image"></a>
                       
                      </div>
                      <div class="card-body">
                        <h3 class="product-title mb-2 fs-base"><a class="d-block text-truncate" href="nft-single-buy.html"><?=$label_list;?></a></h3><span class="fs-sm text-muted">Earning:</span>
                        <div class="d-flex align-items-center flex-wrap">
                          <h4 class="mt-1 mb-0 fs-base text-darker"><?=$amount;?> NG</h4><span class="mt-1 ms-1 fs-xs text-muted">Invested for<?=$duration;?> days</span>
                        </div><div class="d-flex align-items-center flex-wrap">
                          <h4 class="mt-1 mb-0 fs-base text-darker"><?=$amount * $incomePercentage_list;?> NG</h4><span class="mt-1 ms-1 fs-xs text-muted"> income On loading...</span>
                        </div>
                      </div>
                      <div class="card-footer mt-n1 py-0 border-0">
                        <div class="d-flex align-items-center position-relative mb-1 py-3 border-top"><img class="me-2 rounded-circle" src="./<?=$companyLogo_list;?>" width="32" alt="Avatar"><a class="nav-link-style fs-sm stretched-link" href="nft-vendor.html">@<?=$companyName_list;?></a></div>
                      </div>
                    </article>
                  </div>
                 
<?php
           }
}

?>


                </div>
              </div>
            </section>
          </div>
        </div>
      </div>
    </main><?php

require './footer.php';
}
?>
