
<?php
session_start();
if (empty($_SESSION['KoKOMelon'])) {
    header("Location: ./sign.php");
}
else {
require './materia.php';
require './h2.php';

$servername = "localhost";
$username = "root";
$serverKey = "";
$dbname = "Mr.404";
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $serverKey);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $stmt = $conn->prepare("SELECT * FROM MyGuests WHERE id='".$_SESSION['KoKOMelon']."'");
    $stmt->execute();
    foreach ($stmt as $key) {
      $firstname = $key['firstname'];
      $lastname = $key['lastname'];
      $email = $key['email'];
      $phone = $key['phone'];
      $profile = $key['profile'];
      $date = $key['date'];
    }
?>
<br>
<br>
<br>
<br>
      <div class="page-title-overlap bg-accent pt-4">
        <div class="container d-flex flex-wrap flex-sm-nowrap justify-content-center justify-content-sm-between align-items-center mb-2 pt-2">
          <div class="d-flex align-items-center">
            <div class="img-thumbnail rounded-circle position-relative flex-shrink-0" style="width: 6.375rem;"><img class="rounded-circle" src="./files/<?=$profile;?>" alt="@foxnet_creator"></div>
            <div class="ps-3">
              <h3 class="h5 mb-2 text-light">@<?=$firstname;?></h3><span class="d-block text-light fs-sm opacity-60">Joined <?=$date;?></span>
            </div>
          </div>
       
        </div>
      </div>
      <div class="container mb-5 pb-3">
        <div class="bg-light shadow-lg rounded-3 overflow-hidden">
          <div class="row">
            <!-- Sidebar-->
           <?php require './aside.php'; ?>
            <!-- Content-->
            <section class="col-lg-9 pt-lg-4 pb-4 mb-3">
              <div class="pt-2 px-4 ps-lg-0 pe-xl-5">
                <h1 class="h3 mb-4 pt-2 text-center text-sm-start">Withdraw</h1>
                     <!--  -->
                             <form  action="./WMS.php" method="POST">
                  <div class="row gy-3 mb-4 pb-md-3 mb-2">
                    <div class="col-sm-6">
                      <label class="form-label" for="profile-name">Bank Name</label>
                      <input class="form-control" id="profile-name" type="text" required="">
                    </div>
                    <div class="col-sm-6">
                      <label class="form-label" for="profile-username">Amount to withdraw</label>
                      <input class="form-control" id="profile-username" type="number" required="">
                    </div>
                    <div class="col-sm-6">
                      <label class="form-label" for="profile-uid">Password</label>
                      <input class="form-control" id="profile-uid" type="password" required="">
                    </div>                           
                      <div class="text-muted">Note: Your will recieve the fund with in 2 - 3 working days</div>
                  </div>
                  <!-- Submit-->
                  <div class="d-flex flex-sm-row flex-column">
                    <button class="btn btn-accent" type="submit">Withdraw</button>
                  </div>
                </form>
                     <!--  -->
              </div>
            </section>
          </div>
        </div>
      </div>
    </main><?php

require './footer.php';
}
?>
