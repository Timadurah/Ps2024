<?php
session_start();
$code = 'ps2024';
if ($_POST['pussy_pass_code'] == $code) {
    $_SESSION['pussy_response'] = null;
    $_SESSION['pussy'] = $code;
    header("location: ./smile@pussy.php");

    
}
elseif (empty($_POST['pussy_pass_code'])) {
    $_SESSION['pussy_response'] = 'Your pass code is required!';
    header("location: ./smile.php");
}
else{
    $_SESSION['pussy_response'] = 'You entered incorrect pass code.';
    header("location: ./smile.php");

}



?>