<?php
session_start();
$servername = "localhost";
$username = "root";
$serverKey = "";
$dbname = "Mr.404";
  $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $serverKey);
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
if (empty($_POST['Recorv_mail'])) {
  $_SESSION['fg_response'] = 'Please Enter your account email';
  header("location: ./account-password-recovery.php");
}
else {
  $recorverEmail = strip_tags($_POST['Recorv_mail']);
  $stmt = $conn->prepare("SELECT email FROM MyGuests WHERE email='".$recorverEmail."'");
  $stmt->execute();
  $counter_ = $stmt->rowCount();
  if ($counter_ > 0) { 
    $one= random_int(1,9);
    $two= rand(1,9);
    $three= rand(1,9);
    $four= rand(1,9);
    $five= rand(1,9);
    $six= rand(1,9);
    $otp = $one."".$two."".$three."".$four."".$five."".$six;
      // send email
      mail($recorverEmail, $uses['companyName']." Verification Code.", $otp);
    // Verification_Now
    // our SQL statements
    $otp_in = $conn->prepare("INSERT INTO Verification_Now (mail, Verivication_code) VALUES ('".$recorverEmail."', '".$otp."')");
    $otp_in->execute();
    $_SESSION['fg_mail'] = $recorverEmail;
    $_SESSION['fg_response'] = null; 
    header("location: ./account-password-recovery_otp.php");
}
else {
$_SESSION['fg_response'] = 'This mail has not been registered';
header("location: ./account-password-recovery.php");    
}
}
?>