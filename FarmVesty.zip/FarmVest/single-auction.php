
<?php
session_start();
if (empty($_SESSION['KoKOMelon'])) {
    header("Location: ./sign.php");
}
else {
require './materia.php';
require './h2.php';

$servername = "localhost";
$username = "root";
$serverKey = "";
$dbname = "Mr.404";
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $serverKey);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $ids =  strip_tags($_GET['Token']);
    $stmt = $conn->prepare("SELECT * FROM availableinvestment WHERE Token_ID='".$ids."'");
    $stmt->execute();
    foreach ($stmt as $key) {
      $availableinvestment_ID = $key['id'];
      $label = $key['label'];
      $banner = $key['banner'];
      $countdown = $key['countdown'];
      $description = $key['description'];
      $AlgoOpen = $key['AlgoOpen'];
      $AlgoTakeprofit = $key['AlgoTakeprofit'];
      $companyName = $key['companyName'];
      $companyLogo = $key['companyLogo'];
      $currentBid = $key['currentBid'];
      $incomePercentage = $key['incomePercentage'];
      $date = $key['date'];
      $farmType = $key['farmType'];
      $Contract_Address = $key['Contract_Address'];
      $Token_ID = $key['Token_ID'];
      $Token_Standard = $key['Token_Standard'];
      $Family = $key['Family'];
      $min_duration = $key['min_duration'];
    }
    $_SESSION['token_ids'] = $Token_ID;
    $_SESSION['currentBid'] = $currentBid;
?>
<br>
<br>
<br>
<br>
      <!-- Page Title-->
      <div class="page-title-overlap bg-accent pt-4">
        <div class="container d-lg-flex justify-content-between py-2 py-lg-3">
          <div class="order-lg-2 mb-3 mb-lg-0 pt-lg-2">
            <nav aria-label="breadcrumb">
              <ol class="breadcrumb breadcrumb-light flex-lg-nowrap justify-content-center justify-content-lg-start">
                <li class="breadcrumb-item"><a class="text-nowrap" href="index.html"><i class="ci-home"></i>Home</a></li>
                </li>
                <li class="breadcrumb-item text-nowrap active" aria-current="page"><?=$label?></li>
              </ol>
            </nav>
          </div>
        </div>
      </div>
      <section class="container pb-md-4">
        <!-- Product-->
        <div class="bg-light shadow-lg rounded-3 px-4 py-lg-4 py-3 mb-5">
          <div class="py-lg-3 py-2 px-lg-3">
            <div class="row gy-4">
              <!-- Product image-->
              <div class="col-lg-6">
                <div class="position-relative rounded-3 overflow-hidden mb-lg-4 mb-2"><img class="image-zoom" src="./<?=$banner;?>" data-zoom="./<?=$banner;?>" alt="<?=$label;?>">
                  <div class="image-zoom-pane"></div>
                </div>
               
              </div>
              <!-- Product details-->
              <div class="col-lg-6">
                <div class="ps-xl-5 ps-lg-3">
                  <!-- Meta-->
                  <h2 class="h3 mb-3"><?=$label;?></h2>
                  <div class="d-flex align-items-center flex-wrap text-nowrap mb-sm-4 mb-3 fs-sm">
                    <div class="mb-2 me-sm-3 me-2 text-muted">Lunched on <?=$date;?></div>
                    <div class="mb-2 me-sm-3 me-2 ps-sm-3 ps-2 border-start text-muted"><i class="ci-wallet me-1 fs-base mt-n1 align-middle"></i><?=$countdown;?> space Launched</div>
                    
                  <div class="row col-12 row-cols-sm-2 row-cols-1 gy-3 gx-4 pb-md-2">
                    <!-- Creator-->
                    <div class="col">
                      <div class="card position-relative h-100">
                        <div class="card-body p-3">
                          <h3 class="h6 mb-2 fs-sm text-muted">Company</h3>
                          <div class="d-flex align-items-center"><img class="rounded-circle me-2" src="./<?=$companyLogo;?>" width="32" alt="Avatar"><a class="nav-link-style stretched-link fs-sm" href="nft-vendor.html">@<?=$companyName;?></a></div>
                        </div>
                      </div>
                    </div>
                    <!-- Collection-->
                    <div class="col">
                      <div class="card position-relative h-100">
                        <div class="card-body p-3">
                          <h3 class="h6 mb-2 fs-sm text-muted">Farm Type</h3>
                          <div class="d-flex align-items-center"><img class="rounded-circle me-2" src="img/nft/catalog/avatars/13.png" width="32" alt="Avatar"><a class="nav-link-style stretched-link fs-sm" href="nft-catalog-v2.html"><?=$farmType;?></a></div>
                        </div>
                      </div>
                    </div>
                  </div></div>
                <h3 class="widget-title text-muted pb-1">Process</h3>

                  <div class="row col-12 row-cols-sm-2 row-cols-1 gy-3 gx-4 mb-4 pb-md-2 ">
                    <!-- Creator-->
                    <div class="col">
                      <div class="card position-relative h-100">
                        <div class="card-body p-3">
                          <h3 class="h6 mb-2 fs-sm text-muted">Opened</h3>
                          <div class="d-flex align-items-center"><a class="nav-link-style stretched-link fs-sm" href="nft-vendor.html">@ <?=$AlgoOpen;?></a></div>
                        </div>
                      </div>
                    </div>
                    <!-- Collection-->
                    <div class="col">
                      <div class="card position-relative h-100">
                        <div class="card-body p-3">
                          <h3 class="h6 mb-2 fs-sm text-muted">Harvest</h3>
                          <div class="d-flex align-items-center"><a class="nav-link-style stretched-link fs-sm" href="nft-catalog-v2.html">@ <?=$AlgoTakeprofit;?> set</a></div>
                        </div>
                      </div>
                    </div>
                  </div>
                  </div>
                  <form action="./invest_submit.php" method="post">
                  <!-- input  the amount you want to ivest and if it wallet cash is lower promp deposit to make the investment  -->
                  <div class="widget pb-3 mb-lg-4">
                <h3 class="widget-title text-muted pb-1">Create your plan</h3>
                  <div class="input-group flex-nowrap"><i class="ci-wallet position-absolute top-50 translate-middle-y text-muted fs-base ms-3"></i>
                    <input class="form-control rounded-start" id="amount" type="number" name="amount" placeholder="Not less than <?=$currentBid;?>"
                     required="">
                    <div class="btn btn-accent">Invest Amount*</div>
                  </div>
                 <div class="input-group flex-nowrap my-3">
                  <select class="form-select" id="duration" required="" name="duration">
                    <option value="">Duration</option>
                    <option value="<?=$min_duration;?>" name="duration" ><?=$min_duration;?> days</option>
                    <option value="<?=$min_duration * 2;?>" name="duration" ><?=$min_duration * 2;?> days</option>
                    <option value="<?=$min_duration * 3;?>" name="duration" ><?=$min_duration * 3;?> days</option>
                    <option value="<?=$min_duration * 4;?>" name="duration" ><?=$min_duration * 4;?> days</option>
                    <option value="<?=$min_duration * 5;?>" name="duration" ><?=$min_duration * 5;?> days</option>
                    <option value="<?=$min_duration * 6;?>" name="duration" ><?=$min_duration * 6;?> days</option>
                    <option value="<?=$min_duration * 7;?>" name="duration" ><?=$min_duration * 7;?> days</option>
                    <option value="<?=$min_duration * 8;?>" name="duration" ><?=$min_duration * 8;?> days</option>
                    <option value="<?=$min_duration * 9;?>" name="duration" ><?=$min_duration * 9;?> days</option>
                    <option value="<?=$min_duration * 10;?>" name="duration" ><?=$min_duration * 10;?> days</option>
                    <option value="<?=$min_duration * 11;?>" name="duration" ><?=$min_duration * 11;?> days</option>
                    <option value="<?=$min_duration * 12;?>" name="duration" ><?=$min_duration * 12;?> days</option>
                    <option value="<?=$min_duration * 13;?>" name="duration" ><?=$min_duration * 13;?> days</option>
                    <option value="<?=$min_duration * 14;?>" name="duration" ><?=$min_duration * 14;?> days</option>
                    <option value="<?=$min_duration * 15;?>" name="duration" ><?=$min_duration * 15;?> days</option>
                    <option value="<?=$min_duration * 16;?>" name="duration" ><?=$min_duration * 16;?> days</option>
                    <option value="<?=$min_duration * 17;?>" name="duration" ><?=$min_duration * 17;?> days</option>
                    <option value="<?=$min_duration * 18;?>" name="duration" ><?=$min_duration * 18;?> days</option>
                    <option value="<?=$min_duration * 19;?>" name="duration" ><?=$min_duration * 19;?> days</option>
                    <option value="<?=$min_duration * 20;?>" name="duration" ><?=$min_duration * 20;?> days</option>
                  </select>
                   
                    <div class="btn btn-accent" >Duration*</div>
                  </div>    
                <h3 class="widget-title pb-1" id="result">
                  <!-- live profit in sososo date -->
                  <?=@$_SESSION['invest_respondi'];?>
                  <?php
                  if (@$_SESSION['invest_respondi_c']  == 1) {
                    $_SESSION['invest_respondi'] = null;
                    $_SESSION['invest_respondi_c'] = null;
                  }
?>
                </h3>        
              </div>
                  <!-- Place a bid--><button class="btn btn-lg btn-accent d-block w-100 mb-4" onclick="invest()">Invest</button>
                  </form>
                  <!-- Product info-->

                  <div class="pt-3">
                    <!-- Nav tabs-->
                    <div class="mb-4" style="overflow-x: auto;">
                      <ul class="nav nav-tabs nav-fill flex-nowrap text-nowrap mb-1" role="tablist">
                        <li class="nav-item"><a class="nav-link active" href="#details" data-bs-toggle="tab" role="tab">Details</a></li>
                                              </ul>
                    </div>
                    <!-- Tabs content-->
                    <div class="tab-content">
                      <!-- Details-->
                      <div class="tab-pane fade show active" id="details" role="tabpanel">
                        <ul class="list-unstyled mb-0">
                          <li class="d-flex flex-sm-row flex-column align-items-sm-center justify-content-between mb-2 fs-sm"><span>Contract Address</span>
                            <div><a class="text-decoration-none" href="#"><span class="fw-medium text-body"><?=substr($Contract_Address, 13);?>...<?=substr($Contract_Address, -3);?></span><i class="ci-external-link ms-3 text-accent"></i></a></div>
                          </li>
                          <li class="d-flex flex-sm-row flex-column align-items-sm-center justify-content-between mb-2 fs-sm"><span>Token ID</span>
                            <div><a class="text-decoration-none" href="#"><span class="text-body"><?=substr($Token_ID, 15);?>...</span><i class="ci-copy ms-3 text-accent"></i></a></div>
                          </li>
                          <li class="d-flex flex-sm-row flex-column align-items-sm-center justify-content-between mb-2 fs-sm"><span>Token Standard</span>
                            <div><span class="text-body"><?=$Token_Standard;?></span></div>
                          </li>
                          <li class="d-flex flex-sm-row flex-column align-items-sm-center justify-content-between mb-2 fs-sm"><span>Family</span>
                            <div><span class="text-body"><?=$Family;?></span></div>
                          </li>
                          <li class="d-flex flex-sm-row flex-column align-items-sm-center justify-content-between mb-2 fs-sm"><span><?=$min_duration;?>days income</span>
                            <div><span class="text-body"><?=$incomePercentage * 100 - 100;?>%</span></div>
                          </li>
                        </ul>
                      </div>
                    
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
          <!-- Vendor scrits: js libraries and plugins-->
    <script src="vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <script src="vendor/simplebar/dist/simplebar.min.js"></script>
    <script src="vendor/tiny-slider/dist/min/tiny-slider.js"></script>
    <script src="vendor/smooth-scroll/dist/smooth-scroll.polyfills.min.js"></script>
    <script src="vendor/drift-zoom/dist/Drift.min.js"></script>
    <!-- Main theme script-->
    <script src="js/theme.min.js"></script>
<?php

require './footer.php';
}
?>



