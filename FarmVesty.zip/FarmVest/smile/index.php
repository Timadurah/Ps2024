<?php
header('location: ../smile.php');
?>