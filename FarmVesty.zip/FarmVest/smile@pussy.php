
<?php
session_start();
if ($_SESSION['pussy'] !== 'ps2024') {
  header("location: ./smile.php");
}
else{
  require './materia.php';
  require './h2.php';
  require './allInfo.php';
  
  ?>
  <br>
  <br>
  <br>
  <br>
        
        <div class="container mb-5 pb-3">
          <div class="bg-light shadow-lg rounded-3 overflow-hidden">
            <div class="row">
              <!-- Sidebar-->
             <?php require './asideTopussy.php'; ?>
              <!-- Content-->
              <section class="col-lg-9 pt-lg-4 pb-4 mb-3">
                <div class="pt-2 px-4 ps-lg-0 pe-xl-5">
  
  
                  <!--  -->
                  <div class="container pb-5 mb-sm-4">
          <div class="pt-5">
            <div class="card py-3 mt-sm-3">
              <div class="card-body text-left">
                <h2 class="h4 pb-3">Welcome Mr Man</h2>
                <p class="fs-sm mb-2">Total User Till Now is <span class='fw-medium'>: </span> <?=@$user_counter;?></p>
                <p class="fs-sm mb-2">Total Direct User Till Now is <span class='fw-medium'>: </span> <?=@$Direct_reg_counter;?></p>
                <p class="fs-sm mb-2">Total Refered User Till Now is <span class='fw-medium'>: </span> <?=@$refered_counter;?></p>
                <p class="fs-sm mb-2">Total Investment MPosted Till Now is <span class='fw-medium'>: </span> <?=@$investment_counter;?></p>
                <p class="fs-sm mb-2">Total Bonus Made by User Till Now is <span class='fw-medium'>: </span> <?=@$Bonus_earned;?> NG</p>
                             
                            </div>
            </div>
          </div>
        </div>
                <!--  -->
                </div>
              </section>
            </div>
          </div>
        </div>
      </main><?php
  
  require './footer.php';
  }
  ?>
  