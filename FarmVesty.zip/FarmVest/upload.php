<?php
session_start();
$servername = "localhost";
$username = "root";
$serverKey = "";
$dbname = "mr.404";
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $serverKey);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    // get info from form
    // import Upload func
    require './uploadModule.php';
    $tier = $_POST['tier'];
    $label = $_POST['label'];
    $description = $_POST['description'];
    $banner =  Upload('banner');
    $countDown = $_POST['countDown'];
    $min_duration = $_POST['min_duration'];
    $farmType = $_POST['farmType'];
    $family = $_POST['family'];
    $lowestBid = $_POST['lowestBid'];
    $incomePercentage = $_POST['incomePercentage'];
    $AlgoOpen = $_POST['AlgoOpen'];   
    $AlgoHarvest = $_POST['AlgoHarvest'];   
    $comapnyName = $_POST['comapnyName'];   
    $companyLogo = Upload('companyLogo');   
    $one= random_int(1,9);
    $two= rand(1,9);
    $three= rand(1,9);
    $four= rand(1,9);
    $five= rand(1,9);
    $six= rand(1,9);
    $Token_standard = 'FXK-'.$five.$six.$one;
    $Current_Address = '0x1d5s-'.$five.$six.$one.$four.$five.$six.$one.$four.$five.$six.$one.$four;
    $RandyNumber = $one.$two.$three.$four.$five.$six.$one.$two.$three.$four.$five.$six.$one.$two.$three.$four.$five.$six.$one.$two.$three.$four.$five.$six.$one.$two.$three.$four.$five.$six;
    // countDown,min_duration,farmType,family,lowestBid,incomePercentage,comapnyName,companyLogo 
    // our SQL statements
    $stmt = $conn->prepare("INSERT INTO `availableinvestment`(`label`, `banner`, `farmType`, `countdown`, `description`, `AlgoOpen`, `AlgoTakeprofit`, `companyName`, `companyLogo`, `currentBid`, `incomePercentage`, `tier`, `Contract_Address`, `Token_ID`, `Token_Standard`, `Family`, `min_duration`) 
    VALUES ('".$label."','".$banner."','".$farmType."','".$countDown."','".$description."','".$AlgoOpen."','".$AlgoHarvest."','".$comapnyName."','".$companyLogo."','".$lowestBid."','".$incomePercentage."','".$tier."','".$Current_Address."','".$RandyNumber."','".$Token_standard."','".$family."','".$min_duration."')");
    // commit the transaction
    if ($stmt->execute()) {
        header("location: ./done__.php");
    }
    

$conn = null;
?>