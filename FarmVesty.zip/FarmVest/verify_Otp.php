<?php
$servername = "localhost";
$username = "username";
$serverKey = "password";
$dbname = "mr.404";

// datas
$otp = $_POST['otp'];
  if (empty($otp)) {
    $_SESSION['otp_response'] = 'Verification is requred';
         }
                    else {
                        
                    
try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $serverKey);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $stmt = $conn->prepare("SELECT * FROM forget_password WHERE otp='".$otp."'");
    $count = $rowCount->stmt;
    $stmt->execute();
    if ($count > 0) {
          foreach ($stmt as $key) {
                      $refine_paasword = password_hash($key['new_password'], PASSWORD_DEFAULT);
        // insert into forget passord table
         // our SQL statements
    $stmt = $conn->prepare("UPDATE MyGuests SET passwd = '".$refine_paasword."' WHERE email = '".$key['email']."'");
    // commit the transaction
    $stmt->execute();
    $_SESSION['otp_response'] = null;
        header("Location: ./");
    }
    else {
        $_SESSION['otp_response'] = 'Verification Code has expired or incorrect';
    }
    
}
}
   
catch(PDOException $e) {
    $_SESSION['otp_response'] = 'Make sure your detail are fill properly';
}
$conn = null;
}
?>